
LOAD DATA LOCAL INFILE 'c:/20131201.txt' INTO TABLE dreamlog.vitals 
FIELDS TERMINATED BY ','
ENCLOSED BY '"'
LINES TERMINATED BY '\r\n'
(EntryID, CurrentTime, Noise);
SET SQL_SAFE_UPDATES=0;
UPDATE dreamlog.vitals SET EntryID = 1;  # for testing purposes

INSERT INTO dreamlog.users (UserName, Password, FirstName, LastName, Age, Gender)
SELECT 'JDoe', 'jkl', 'John', 'Doe', 24, 'M'


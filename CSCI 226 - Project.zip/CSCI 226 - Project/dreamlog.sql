create database dreamlog;
use dreamlog;

create table users (
UserID int not null auto_increment,
UserName varchar(25),
FirstName varchar(25),
LastName varchar(25),
Age INT,
Gender char(1),
PRIMARY KEY (UserID)
);

create table feelings (
FeelingID int not null auto_increment,
Description varchar(300),
PRIMARY KEY (FeelID)
);

create table entries (
EntryID int not null auto_increment,
UserID int,
Description text,
Analysis text,
LastFood varchar(100),
FeelingID int,
Rating int,
Permission int,
ModifiedDate datetime,
CreateDate datetime,
PRIMARY KEY (EntryID)
);

create table comments (
CommentID int not null auto_increment,
EntryID int,
ReplyID int,  # references another CommentID
Description varchar(500),
UserID int,
CreateDate datetime,
PRIMARY KEY (CommentID)
);

create table vitals (
VitalID int not null auto_increment,
EntryID int,
Noise int,
Description varchar(500),
CurrentTime time,
PRIMARY KEY (VitalID)
);
